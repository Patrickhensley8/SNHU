#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    float Initial, monthlyDep, Interest, Years, Total, annualInt, yearlyInterest, Restart;
    Restart = 'Y';
    while (Restart == 'Y' || Restart == 'y') {
        Restart = 'Y';
        Initial = 0;
        monthlyDep = 0;
        Interest = 0;
        Years = 0;

        //Intial display for the main screen
        cout << "--------------------------------" << endl;
        cout << "---------- User Inputs ----------" << endl;
        cout << "Initial Investment Amount: " << endl;
        cout << "Monthly Deposit: " << endl;
        cout << "Annual Interest: " << endl;
        cout << "Number of Years: " << endl;

        system("PAUSE");
        //display where user inputs information (Initial investment, Monthly Deposit, Annual Interest and Years)
        cout << "--------------------------------" << endl;
        cout << "---------- User Inputs ----------" << endl;
        cout << "Initial Investment Amount: $";
        cin >> Initial;
        cout << "Monthly Deposit: $";
        cin >> monthlyDep;
        cout << "Annual Interest: ";
        cin >> Interest;
        cout << "Number of Years: ";
        cin >> Years;

        system("PAUSE");
        //Year 0 is the initial investment
        Total = Initial;
        //Display the numbers
        cout << endl << "Balance and Interest Without Additional Monthly Deposits" << endl;
        cout << "--------------------------------------------------------------" << endl;
        cout << "Year     Year End Balance     Year End Earned Interest" << endl;
        cout << "--------------------------------------------------------------" << endl;
        //for loop to display the correct number of years
        for (int i = 0; i < Years; i++) {
            annualInt = (Total) * ((Interest / 100));
            Total = Total + annualInt;
            cout << (i + 1) << "              $" << fixed << setprecision(2) << Total << "              $" << annualInt << endl;
        }
        //Year 0 is the initial investment
        Total = Initial;

        cout << endl << "Balance and Interest With Additional Monthly Deposits" << endl;
        cout << "-------------------------------------------------------------" << endl;
        cout << "Year     Year End Balance     Year End Earned Interest" << endl;
        cout << "-------------------------------------------------------------" << endl;
        //for loop to display the correct number of years
        for (int i = 0; i < Years; i++) {
            yearlyInterest = 0;
            for (int j = 0; j < 12; j++) {
                annualInt = (Total + monthlyDep) * ((Interest / 100) / 12);
                yearlyInterest = annualInt + yearlyInterest;
                Total = Total + monthlyDep + annualInt;
            }
            // display amount with 2 decimal places for money
            cout << (i + 1) << "              $" << fixed << setprecision(2) << Total << "              $" << yearlyInterest << endl;
        }
        cout << "Would you like to enter different amounts? Press Y if you want to.";
        cin >> Restart;
    }
        return 0;
}

